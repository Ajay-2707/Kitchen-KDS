/* eslint-disable jsx-a11y/alt-text */
import './App.css';
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import KitchenScreen from "./Components/KitchenScreen";
import config from "./config";
import ConfigModal from "./configModal";
import ConfiguratorPage from "./ConfiguratorPage";
import { MdMoreVert } from "react-icons/md"

function App() {
  const [time, setTime] = useState(new Date());
  const [isModalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000); // update every second

    return () => clearInterval(timer); // cleanup on unmount
  }, []);
  return (
    <Router>
      <div className="app-container">
        {/* Navigation Header */}
        <nav className="nav-header">
          <p>Powered by Synoweb &nbsp;|&nbsp; {config.version}</p>
          <h2 className="kitchen-title">Kitchen Display System</h2>
          <p>{time.toLocaleTimeString()} <button
  onClick={() => setModalOpen(true)}
  style={{
    backgroundColor: 'transparent',
    border: "none",
        cursor: "pointer",
  }}
>
  <MdMoreVert size={20} color="white" />
</button>{/* e.g., 18:45:12 */}</p>
           
        <ConfigModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} />
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/configurator" element={<ConfiguratorPage />} />
          <Route path="/" element={<KitchenScreen />} />
        </Routes>

        {/* Watermark Footer */}
        {/* <footer className="watermark">
          Powered by Synoweb &nbsp;|&nbsp; {config.version}
        </footer> */}
      </div>
    </Router>
  );
}

export default App;
