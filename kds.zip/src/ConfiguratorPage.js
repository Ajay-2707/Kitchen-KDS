import React from "react";
import config from "./config";

function ConfiguratorPage() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Configuration</h1>
      <pre style={{ background: "#f4f4f4", padding: "10px", borderRadius: "8px" }}>
        {JSON.stringify(config, null, 2)}
      </pre>
    </div>
  );
}

export default ConfiguratorPage;
